/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project;

import java.io.File;
import java.io.FileNotFoundException;
import static java.lang.System.out;
import java.util.Scanner;

/**
 *
 * @author mcclejas
 */
public class Project {

    /**
     * @param args the command line arguments
     * @throws java.io.FileNotFoundException
     */
    public static void main(String[] args) throws FileNotFoundException {
    
    
    Scanner kb = new Scanner(System.in); 
    int age = kb.nextInt();
    
    if (age>=18) {
        out.println("can go into a bar can't drink");
    } else {
        out.println("cant go into bar and cant drink");

    }
    
    


    
    }
    
}
